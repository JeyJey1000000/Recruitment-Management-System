<?php
include 'includes/config.php';
session_start();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" href="user.css">
</head>
<body>
<nav class="navbar">

        <ul>
            <li><a href="admin.php">Home</a></li>
            <li><a href="jobseek.php">Job Seekers</a></li>
            
           
            <li><a href="logout.php">Log out</a></li>



        </ul>
    </nav>
    <h1 class= "add">Admin</h1>


   
   
    <table class="content-table">
  <thead>
    <tr>
      <th>id</th>
      <th>company name</th>
      <th>company type</th>
      <th>about</th>
      
    </tr>
  </thead>
  <tbody>
  <?php
    

    $sql = "SELECT * FROM company";
    $query = mysqli_query($conn, $sql);
    while($fetch = mysqli_fetch_assoc($query)){
        echo "<tr><td>" . $fetch['id'] . "</td><td>" . $fetch['cname']
         . "</td><td>" . $fetch['ctype'] . "</td><td>" . $fetch['about'] . "</td></tr>";
    } 
       
    

    ?>
   
    <tr>
      <td><?php  echo $fetch['id']; ?></td>
      <td><?php  echo $fetch['reciever']; ?></td>
        
      <td><?php  echo $fetch['amount'] . "<br>";?></td>
      
    </tr>
    
  </tbody>
</table>

    
</body>
</html>