<?php
include 'includes/config.php';
session_start();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" href="user.css">
</head>
<body>
<nav class="navbar">

        <ul>
            <li><a href="admin.php">Admin</a></li>
            <li><a href="jobseek.php">Job Seekers</a></li>
            
           
            <li><a href="logout.php">Log out</a></li>



        </ul>
    </nav>
    <h1>Job Seekers</h1>


   
   
    <table class="content-table">
  <thead>
    <tr>
      <th>id</th>
      <th>company name</th>
      <th>company type</th>
      <th>about</th>
      
    </tr>
  </thead>
  <tbody>
  <?php
    

    $sql = "SELECT * FROM seeker";
    $query = mysqli_query($conn, $sql);
    while($fetch = mysqli_fetch_assoc($query)){
        echo "<tr><td>" . $fetch['id'] . "</td><td>" . $fetch['firstname']
         . "</td><td>" . $fetch['email'] . "</td><td>" . $fetch['edu_background'] . "</td></tr>";
    } 
       
    

    ?>
   
    <tr>
      <td><?php  echo $fetch['id']; ?></td>
      <td><?php  echo $fetch['reciever']; ?></td>
        
      <td><?php  echo $fetch['amount'] . "<br>";?></td>
      
    </tr>
    
  </tbody>
</table>

    
</body>
</html>