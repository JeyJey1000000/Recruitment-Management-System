<?php
    $localhost = "localhost";
    $db_user = "root";
    $db_password = "";
    $db_name = "search_job";

    $conn = mysqli_connect($localhost, $db_user, $db_password, $db_name);

    if($conn){
        

    }else{
        echo "connection failed";
    }
?>